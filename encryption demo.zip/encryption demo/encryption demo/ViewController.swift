//
//  ViewController.swift
//  encryption demo
//
//  Created by Sachin Raut on 17/12/18.
//  Copyright © 2018 Sachin Raut. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{

    override func viewDidLoad()
    {
        super.viewDidLoad()
        let encryptedData = encryptData(name: "Mumbai")
        let encryptedString = "Encrypted string of Mumbai = " + encryptedData
        print(encryptedString)
        
        let decryptedData = decryptData(dataToBeDecrypted: encryptedData)
        
        print(decryptedData)
    }

    
    func encryptData(name: String) -> String
    {
        let data = name.data(using: String.Encoding.utf8)
        let encryptedData = RNCryptor.encrypt(data: data!, withPassword: "yourKey")
        
        return encryptedData.base64EncodedString(options: NSData.Base64EncodingOptions.init(rawValue: 0))
    }
    
    func decryptData(dataToBeDecrypted: String) -> String
    {
        let decryptor = RNCryptor.Decryptor(password: "yourKey")
        
        let encryptedData = NSData(base64Encoded: dataToBeDecrypted, options: NSData.Base64DecodingOptions.init(rawValue: 0))
        
        var message = ""
        
        do
        {
            let decryptedData = try decryptor.decrypt(data: encryptedData! as Data)
            message = String(data: decryptedData, encoding: String.Encoding(rawValue: String.Encoding.utf8.rawValue))!
        }
        catch
        {
            print("Error while decoding text \(error)")
        }
        return message
    }

}

